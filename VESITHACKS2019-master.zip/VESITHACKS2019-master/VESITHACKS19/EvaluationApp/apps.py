from django.apps import AppConfig


class EvaluationappConfig(AppConfig):
    name = 'EvaluationApp'
